# otus_homeworks
Homeworks from Otus python developer course
